# Node.js Authentication Backend with PostgreSQL

A basic authentication backend project built with Node.js, Express, and PostgreSQL. This project is designed for developers learning Node.js to understand authentication fundamentals while following industry best practices.

## Features

- **User Registration**: Create new accounts with email and password
- **User Login**: Authenticate and receive a JWT (JSON Web Token)
- **Protected Routes**: Access user-specific endpoints with authentication
- **Password Hashing**: Secure password storage using bcrypt
- **Input Validation**: Request validation using express-validator
- **Clean Architecture**: Separation of concerns with controllers, middleware, and routes

## Project Structure

```
node-auth-backend/
├── src/
│   ├── config/
│   │   ├── db.js              # Database connection configuration
│   │   └── initDatabase.js    # Database initialization script
│   ├── controllers/
│   │   └── authController.js  # Authentication business logic
│   ├── middlewares/
│   │   ├── auth.js            # JWT authentication middleware
│   │   └── validation.js      # Request validation middleware
│   ├── routes/
│   │   └── authRoutes.js      # API route definitions
│   ├── utils/
│   │   └── errorResponse.js   # Error handling utilities
│   ├── app.js                 # Express application setup
│   └── server.js              # Server entry point
├── database.sql               # Database schema
├── .env.example               # Environment variables template
├── .gitignore
├── package.json
└── README.md
```

## Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** (v14 or higher) - [Download here](https://nodejs.org/)
- **PostgreSQL** (v12 or higher) - [Download here](https://www.postgresql.org/)
- **npm** or **yarn** (comes with Node.js)

## Quick Start

### 1. Clone and Install Dependencies

```bash
cd node-auth-backend
npm install
```

### 2. Configure Environment Variables

Copy the example environment file and update it with your settings:

```bash
cp .env.example .env
```

Edit `.env` with your PostgreSQL credentials:

```env
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=nodeauth
DB_USER=postgres
DB_PASSWORD=your_password_here

# JWT Configuration
JWT_SECRET=your_super_secret_key_change_this
JWT_EXPIRE=24h

# Server Configuration
PORT=3000
NODE_ENV=development
```

### 3. Create the Database

Create a new PostgreSQL database:

```sql
CREATE DATABASE nodeauth;
```

Or using command line:

```bash
createdb nodeauth
```

### 4. Initialize the Database

Run the initialization script to create the users table:

```bash
npm run init-db
```

Or manually execute the SQL script:

```bash
psql -U postgres -d nodeauth -f database.sql
```

### 5. Start the Server

```bash
# Development mode (with auto-reload)
npm run dev

# Production mode
npm start
```

The server will start at `http://localhost:3000`

## API Endpoints

### Authentication Routes

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| POST | `/api/auth/register` | Register a new user | Public |
| POST | `/api/auth/login` | Login and get token | Public |
| GET | `/api/auth/me` | Get current user profile | Private |
| POST | `/api/auth/logout` | Logout user | Private |

### System Routes

| Method | Endpoint | Description | Access |
|--------|----------|-------------|--------|
| GET | `/` | API information | Public |
| GET | `/health` | Health check | Public |

## API Usage Examples

### Register a New User

**Request:**

```http
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "securepassword123"
}
```

**Response (201 Created):**

```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "John Doe",
      "email": "john@example.com",
      "createdAt": "2024-01-01T00:00:00.000Z"
    }
  }
}
```

### Login

**Request:**

```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "securepassword123"
}
```

**Response (200 OK):**

```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "John Doe",
      "email": "john@example.com"
    }
  }
}
```

### Get Current User Profile

**Request:**

```http
GET /api/auth/me
Authorization: Bearer <your_token_here>
```

**Response (200 OK):**

```json
{
  "success": true,
  "data": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "name": "John Doe",
    "email": "john@example.com",
    "createdAt": "2024-01-01T00:00:00.000Z",
    "updatedAt": "2024-01-01T00:00:00.000Z"
  }
}
```

### Error Response

**Example Error (400 Bad Request):**

```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    {
      "field": "email",
      "message": "Please provide a valid email"
    }
  ]
}
```

## Security Best Practices Implemented

1. **Password Hashing**: Uses bcrypt with salt rounds to securely hash passwords
2. **Parameterized Queries**: Prevents SQL injection attacks
3. **JWT Authentication**: Stateless authentication using signed tokens
4. **Input Validation**: Validates and sanitizes all user input
5. **Error Handling**: Generic error messages in production (no stack traces)
6. **Environment Variables**: Sensitive data stored in environment variables

## Learning Resources

This project demonstrates several key Node.js concepts:

- **Express.js**: Building REST APIs with Express framework
- **PostgreSQL**: Database operations using node-postgres (pg)
- **Authentication**: JWT-based stateless authentication
- **Middleware**: Request processing pipeline
- **Error Handling**: Centralized error handling
- **Configuration**: Environment-based configuration
- **Async/Await**: Modern JavaScript asynchronous patterns

## Testing the API

You can test the API using:

- **Postman**: Create requests and manage authentication tokens
- **curl**: Command-line HTTP requests

### Example curl commands:

```bash
# Register
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"John Doe","email":"john@example.com","password":"password123"}'

# Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@example.com","password":"password123"}'

# Get Profile (replace TOKEN with actual token)
curl -X GET http://localhost:3000/api/auth/me \
  -H "Authorization: Bearer TOKEN"
```

## Common Issues and Solutions

### Database Connection Failed

1. Make sure PostgreSQL is running
2. Check your `.env` credentials
3. Verify the database exists

```bash
# Check if PostgreSQL is running (macOS)
brew services list | grep postgresql

# Create the database
createdb nodeauth
```

### Port Already in Use

If port 3000 is already in use, change the PORT in `.env`:

```env
PORT=3001
```

### JWT Token Issues

1. Make sure `JWT_SECRET` is set in `.env`
2. Tokens expire after 24 hours (configurable)
3. Include the full token in the Authorization header

## Next Steps

Once you understand this basic auth system, consider adding:

1. **Password Reset**: Email-based password recovery
2. **Token Refresh**: Endpoint to get a new token before expiration
3. **User Management**: CRUD operations for user profiles
4. **Role-Based Access**: Different permission levels (admin, user)
5. **Rate Limiting**: Prevent brute force attacks
6. **API Documentation**: Swagger/OpenAPI documentation

## License

MIT License - Feel free to use this project for learning and development.

## Contributing

This is an educational project. If you find issues or have suggestions, feel free to improve the code and documentation.
